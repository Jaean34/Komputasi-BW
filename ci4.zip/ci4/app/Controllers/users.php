<?php namespace App\Controllers;
 
use CodeIgniter\Controller;
use App\Models\UserModel;
 
class Users extends Controller
{
    public function __construct()
    {
        $this->model = new UserModel();
    }

    public function index() 

    {    
        $model = new UserModel();
 
        $data['users'] = $model->orderBy('id', 'DESC')->findAll();
        
        return view('users', $data);
    }    
 
    public function create()
    {    
        return view('create-user');
    }
 
    public function store() #Untuk menyimpan
    {  
 
        helper(['form', 'url']);
         
        $model = new UserModel();
 
        $data = [
 
            'name' => $this->request->getVar('name'),
            'email'  => $this->request->getVar('email'),
            ];
 
        $save = $model->insert($data);
 
        return redirect()->to( base_url('public/index.php/users') );
    }
 
    public function edit($id = null)
{
    if ($id === null) {
        throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound('ID user tidak diberikan');
    }

    $user = $this->model->find($id);

    if (!$user) { 
        
        throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound("User dengan id ($id) tidak ditemukan");
    }

    return view('edit-user', ['user' => $user]);
}
 
    public function update()
    {  
 
        helper(['form', 'url']);
         
        $model = new UserModel();
 
        $id = $this->request->getVar('id');
 
        $data = [
 
            'name' => $this->request->getVar('name'),
            'email'  => $this->request->getVar('email'),
            ];
 
        $save = $model->update($id,$data);
 
        return redirect()->to( base_url('public/index.php/users') );
    }
 
    public function delete($id = null)
    {
 
     $model = new UserModel();
 
     $data['user'] = $model->where('id', $id)->delete();
      
     return redirect()->to( base_url('public/index.php/users') );
    }
}