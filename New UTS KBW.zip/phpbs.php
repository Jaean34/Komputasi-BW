<?php
$dataDiri = [
    'nama' => 'Karine Olivia Permana', 
    'profesi' => 'Web Developer', 
    'keterangan_profesi' => 'Web Developer',
    'deskripsi' => 'Halo, nama saya Karine. Saya adalah seorang pengembang web yang bersemangat dalam membangun solusi web berskala besar. Saya fokus pada efisiensi kode dan pengalaman pengguna yang luar biasa. Saya lahir di Jakarta dan kini berdomisili di Tangerang Selatan.'
];

$projects = [
    ['title' => 'Educational Web', 'description' => 'Situs pembelajaran online yang mengajarkan kepada para pengguna/masyrakat tentang bahaya narkoba. dampak, serta cara mecegah dari penggunaan narkoba.', 'tags' => 'ActionScript'],
    ['title' => 'E-Commerce', 'description' => 'Membuat sebuah website untuk penjualan donat sehingga dapat membantu meningkatkan jual pasar.', 'tags' => 'ActionScript'],
    ['title' => 'Mobile & Desktop for Web & App Design', 'description' => 'Desain dan prototipe Figma untuk layanan makanan dan edukasi, berfokus pada praktik terbaik UX/UI.', 'tags' => 'Figma, UX/UI, Prototyping'],
];

$favorites = [
   ['name' => 'HTML', 'level' => 'Advanced', 'color' => '#61DAFB'],
    ['name' => 'CSS', 'level' => 'Advanced', 'color' => '#38B2AC'],
    ['name' => 'Python', 'level' => 'Intermediate', 'color' => '#339933'],
    ['name' => 'Figma', 'level' => 'Advanced', 'color' => '#A259FF'],
];

// Mendapatkan nilai page dari URL, defaultnya adalah 'home'
$page = $_GET['page'] ?? 'home'; 

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portofolio | <?= htmlspecialchars($dataDiri['nama']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100..900&display=swap" rel="stylesheet">
    <style>
        :root {
            --color-dark-blue: #080C2C; 
            --color-purple-dark: #3700b3;
            --color-purple-light: #6200ee;
            --color-pink: #BB86FC;
            --color-white: #ffffff;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--color-dark-blue);
            color: var(--color-white);
            min-height: 100vh;
            margin: 0;
            padding: 0;
            background-image: linear-gradient(135deg, #090e38 0%, #170068 100%);
            background-attachment: fixed; 
        }

        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1; 
            background-size: 50px 50px;
            background-image: linear-gradient(to right, rgba(255, 255, 255, 0.05) 1px, transparent 1px),
                              linear-gradient(to bottom, rgba(255, 255, 255, 0.05) 1px, transparent 1px);
        }

        .navbar {
            background-color: transparent !important;
            padding-top: 2rem;
        }

        .navbar-brand {
            font-weight: 700;
            font-size: 1.2rem;
            color: var(--color-white) !important;
        }

        .nav-link {
            color: rgba(255, 255, 255, 0.7) !important;
            margin-right: 1.5rem;
            font-size: 1rem;
            font-weight: 500;
            transition: color 0.3s;
        }
        .nav-link:hover, .nav-link.active {
            color: var(--color-white) !important;
        }
        
        .nav-link.btn-about {
            border: 2px solid var(--color-pink);
            border-radius: 20px;
            padding: 0.5rem 1.5rem;
            color: var(--color-pink) !important;
            background-color: transparent;
        }
        .nav-link.btn-about:hover {
            background-color: rgba(187, 134, 252, 0.1);
        }

        .hero-section {
            padding-top: 5rem;
            padding-bottom: 5rem;
        }

        .profile-title {
            font-size: 4rem;
            font-weight: 900;
            line-height: 1.1;
            margin-bottom: 0.5rem;
        }

        .profile-subtitle {
            font-size: 1.8rem;
            font-weight: 400;
            color: rgba(255, 255, 255, 0.7);
            margin-bottom: 2rem;
        }

        .profile-description {
            font-size: 1.1rem;
            line-height: 1.8;
            color: rgba(255, 255, 255, 0.8);
            max-width: 550px;
            margin-bottom: 3rem;
        }

        .btn-read-more {
            background: linear-gradient(90deg, #6200ee 0%, #BB86FC 100%);
            border: none;
            color: var(--color-white);
            font-weight: 600;
            padding: 0.8rem 2rem;
            border-radius: 8px;
            transition: opacity 0.3s;
        }
        .btn-read-more:hover {
            opacity: 0.9;
        }
        
        .btn-arrow {
            font-size: 2rem;
            color: rgba(255, 255, 255, 0.5);
            margin-left: 1rem;
            cursor: pointer;
        }

        .profile-image-container {
            position: relative;
            width: 350px; 
            height: 450px; 
            margin: 0 auto;
            transition: transform 0.5s ease-in-out, box-shadow 0.5s ease-in-out;
            cursor: pointer;
        }
        .profile-image-container:hover {
            transform: translateY(-10px); 
            box-shadow: 0 15px 40px rgba(187, 134, 252, 0.2); 
        }
        
        .profile-shape {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            border-radius: 60% 40% 70% 30% / 30% 60% 40% 70%; 
            background: linear-gradient(135deg, #FF6F61 0%, #BB86FC 100%); 
            opacity: 0.8;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            overflow: hidden; 
            transform: rotate(-10deg); 
            transition: transform 0.5s ease-in-out;
        }

        .profile-image-container:hover .profile-shape {
             transform: rotate(-5deg); 
        }
        
        .profile-img {
            position: absolute;
            width: 90%;
            height: 90%;
            object-fit: cover;
            top: 5%;
            left: 5%;
            border-radius: 60% 40% 70% 30% / 30% 60% 40% 70%; 
            transform: rotate(10deg); 
            z-index: 2;
        }

        @keyframes rotateText {
            from {
                transform: translate(-50%, -50%) rotate(0deg);
            }
            to {
                transform: translate(-50%, -50%) rotate(360deg);
            }
        }
        
        .circular-text {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 150%;
            height: 150%;
            z-index: 3;
            pointer-events: none;
            animation: rotateText 10s linear infinite; 
        }
        .circular-text-path {
            fill: none;
        }
        .circular-text text {
            fill: rgba(255, 255, 255, 0.5);
            font-size: 10px;
            letter-spacing: 3px;
            font-weight: 600;
            text-transform: uppercase;
        }
        
        .name-box {
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translate(-50%, 50%); 
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 10px;
            padding: 0.75rem 2rem;
            text-align: center;
            font-weight: 700;
            font-size: 1.1rem;
            color: var(--color-white);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.5);
            width: 80%;
            z-index: 10;
            transition: transform 0.5s ease-in-out, box-shadow 0.5s ease-in-out;
        }

        @media (max-width: 992px) {
            .profile-title {
                font-size: 3rem;
            }
            .profile-image-container {
                margin-top: 4rem;
                width: 300px;
                height: 400px;
            }
            .navbar-nav {
                margin-top: 1rem;
                text-align: center;
            }
        }
        @media (max-width: 576px) {
            .profile-title {
                font-size: 2.5rem;
            }
            .profile-subtitle {
                font-size: 1.4rem;
            }
            .btn-arrow {
                display: none;
            }
        }
        
        .project-card {
            background-color: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            padding: 1.5rem;
            margin-bottom: 2rem;
            transition: transform 0.3s, background-color 0.3s;
        }
        .project-card:hover {
            transform: translateY(-5px);
            background-color: rgba(187, 134, 252, 0.05);
        }
        .tag-badge {
            display: inline-block;
            background-color: var(--color-purple-light);
            color: var(--color-white);
            padding: 0.3rem 0.7rem;
            border-radius: 6px;
            font-size: 0.8rem;
            margin-right: 0.5rem;
            margin-top: 0.5rem;
        }
        
        .skill-item {
            display: flex;
            align-items: center;
            margin-bottom: 1rem;
        }
        .skill-bar-container {
            flex-grow: 1;
            height: 8px;
            background-color: rgba(255, 255, 255, 0.1);
            border-radius: 4px;
            overflow: hidden;
            margin-left: 1rem;
        }
        .skill-bar {
            height: 100%;
            border-radius: 4px;
            transition: width 1s ease-out;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container-fluid px-5">
        <a class="navbar-brand" href="phpbs.php?page=home">PORTFOLIO DESIGN</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto align-items-lg-center">
                <li class="nav-item">
                    <a class="nav-link <?= $page === 'home' ? 'active' : '' ?>" href="phpbs.php?page=home">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= $page === 'collection' ? 'active' : '' ?>" href="collection.php?page=collection">Collection</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link btn-about <?= $page === 'about' ? 'active' : '' ?>" href="about.php?page=about">About me</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= $page === 'favorite' ? 'active' : '' ?>" href="favorit.php?page=favorite">Favorite</a>
                </li>
                <li class="nav-item d-none d-lg-block"> 
                    <a class="nav-link <?= $page === 'contact' ? 'active' : '' ?>" href="contact.php?page=contact">Contact</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<?php if ($page === 'home'): ?>
<section class="hero-section" id="hero-section">
    <div class="container-fluid px-5">
        <div class="row align-items-center">
            <div class="col-lg-6 col-md-12 text-center text-lg-start mb-5 mb-lg-0">
                <h1 class="profile-title"><?= htmlspecialchars($dataDiri['profesi']) ?></h1>
                <p class="profile-subtitle"><?= htmlspecialchars($dataDiri['keterangan_profesi']) ?></p>
                
                <div class="profile-description mb-5">
                    <p><?= nl2br(htmlspecialchars($dataDiri['deskripsi'])) ?></p>
                </div>
                
                <div class="d-flex justify-content-center justify-content-lg-start align-items-center">
                    <a href="about.php?page=about" class="btn btn-read-more">Read more</a>
                    <span class="btn-arrow">→</span>
                </div>
            </div>

            <div class="col-lg-6 col-md-12 d-flex justify-content-center">
                <div class="profile-image-container">
                    <div class="profile-shape"></div>
                    
                    <svg viewBox="0 0 100 100" class="circular-text">
                        <defs>
                            <path id="circlePath" d="M 50, 50 m -35, 0 a 35,35 0 1,1 70,0 a 35,35 0 1,1 -70,0" />
                        </defs>
                        <text class="circular-text-path">
                            <textPath xlink:href="#circlePath" startOffset="0%">
                               • WEB DEVELOPER •
                            </textPath>
                        </text>
                    </svg>

                    <img src="https://placehold.co/350x450/6200ee/ffffff?text=Karine" class="profile-img" alt="Foto Profil Karine Olivia Permana">

                    <div class="name-box">
                        <?= htmlspecialchars($dataDiri['nama']) ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php elseif ($page === 'collection'): ?>
<div class="container my-5">
    <h2 class="text-center mb-5 profile-title" style="font-size: 3rem;">My Collection</h2>
    <div class="row justify-content-center">
        <?php foreach ($projects as $project): ?>
        <div class="col-lg-4 col-md-6 mb-4">
            <div class="project-card h-100">
                <h4 class="text-white mb-3"><?= htmlspecialchars($project['title']) ?></h4>
                <p class="text-muted small">Project/Application</p>
                <p><?= htmlspecialchars($project['description']) ?></p>
                <div class="mt-3">
                    <?php foreach (explode(', ', $project['tags']) as $tag): ?>
                        <span class="tag-badge"><?= htmlspecialchars(trim($tag)) ?></span>
                    <?php endforeach; ?>
                </div>
                <div class="d-flex justify-content-end mt-3">
                    <button class="btn btn-sm text-info me-2">Edit (CRUD)</button>
                    <button class="btn btn-sm text-danger">Delete (CRUD)</button>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <div class="text-center mt-5">
        <button class="btn btn-read-more">Add New Project</button>
    </div>
</div>
<?php elseif ($page === 'about'): ?>
<div class="container my-5">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <h2 class="text-center mb-4 profile-title" style="font-size: 3rem;">About Me</h2>
            <div class="card p-5 bg-dark" style="border-radius: 12px;">
                <h4 class="text-pink mb-3">Karine Olivia Permana</h4>
                <p class="fs-5 mb-4 text-white-50"><?= htmlspecialchars($dataDiri['profesi']) ?> | Fullstack Enthusiast</p>
                
                <p style="font-size: 1.1rem; line-height: 1.8;">
                    Saya adalah Karine, seorang pengembang web yang memiliki pengalaman dalam seluruh tumpukan teknologi, mulai dari front-end yang berfokus pada pengalaman pengguna yang intuitif, hingga back-end yang kuat dan arsitektur cloud.
                </p>
                <p style="font-size: 1.1rem; line-height: 1.8;">
                    Saya lahir di Jakarta dan saat ini tinggal di Tangerang Selatan. Selama karir saya, saya telah berhasil memimpin dan berkontribusi pada proyek-proyek yang membutuhkan skalabilitas tinggi dan kinerja optimal. Saya percaya bahwa kunci pengembangan yang baik terletak pada kolaborasi tim yang kuat dan hasrat untuk terus belajar.
                </p>
                <h5 class="text-pink mt-4">Pendidikan</h5>
                <ul class="list-unstyled">
                    <li class="mb-2"><strong>Universitas Teknologi Jakarta</strong> - S1 Teknik Informatika (2015 - 2019)</li>
                    <li><strong>Google Cloud Professional Certification</strong> - 2023</li>
                </ul>
                <h5 class="text-pink mt-4">Lokasi</h5>
                <p>Berasal dari: Jakarta <br> Berdomisili di: Tangerang Selatan</p>
            </div>
        </div>
    </div>
</div>
<?php elseif ($page === 'favorite'): ?>
<div class="container my-5">
    <h2 class="text-center mb-5 profile-title" style="font-size: 3rem;">My Favorite Stacks & Skills</h2>
    <div class="row justify-content-center">
        <?php foreach ($favorites as $fav): ?>
            <?php
                $percent = match ($fav['level']) {
                    'Advanced' => '90%',
                    'Intermediate' => '70%',
                    'Beginner' => '40%',
                    default => '50%',
                };
            ?>
            <div class="col-lg-6 mb-4">
                <div class="skill-item">
                    <div style="width: 120px; font-weight: 600; color: var(--color-pink);"><?= htmlspecialchars($fav['name']) ?></div>
                    <div class="skill-bar-container">
                        <div class="skill-bar" style="width: <?= $percent ?>; background-color: <?= htmlspecialchars($fav['color']) ?>;"></div>
                    </div>
                    <div style="width: 80px; text-align: right; font-size: 0.9rem; color: rgba(255, 255, 255, 0.7);"><?= $percent ?></div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
    <div class="text-center mt-5">
        <p class="text-muted">Skala kemampuan ini berdasarkan pengalaman pribadi dan proyek yang telah diselesaikan. Data diambil dari database (simulasi).</p>
    </div>
</div>
<?php elseif ($page === 'contact'): ?>
<div class="container my-5">
    <div class="row justify-content-center">
        <div class="col-lg-6">
            <h2 class="text-center mb-4 profile-title" style="font-size: 3rem;">Contact Me</h2>
            <div class="card p-4 bg-dark" style="border-radius: 12px;">
                <p class="text-center">
                    Tertarik untuk berkolaborasi atau ingin sekadar menyapa? Silakan kirim pesan melalui formulir di bawah ini.
                </p>
                <form>
                    <div class="mb-3">
                        <label for="name" class="form-label text-pink">Nama Lengkap</label>
                        <input type="text" class="form-control" id="name" style="background: rgba(255, 255, 255, 0.1); border: none; color: white;" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label text-pink">Email</label>
                        <input type="email" class="form-control" id="email" style="background: rgba(255, 255, 255, 0.1); border: none; color: white;" required>
                    </div>
                    <div class="mb-3">
                        <label for="message" class="form-label text-pink">Pesan</label>
                        <textarea class="form-control" id="message" rows="4" style="background: rgba(255, 255, 255, 0.1); border: none; color: white;" required></textarea>
                    </div>
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-read-more">Send Message</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<footer class="text-center py-3" style="background-color: rgba(0, 0, 0, 0.1);">
    <small class="text-muted">&copy; 2024 Portofolio | Creative Designer</small>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

<script type="module">
import { initializeApp } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-app.js";
import { getAuth, signInAnonymously, signInWithCustomToken } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-auth.js";
import { getFirestore, setLogLevel } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-firestore.js";

const initializeFirebase = async () => {
    try {
        const appId = typeof __app_id !== 'undefined' ? __app_id : 'default-app-id';
        const firebaseConfig = JSON.parse(typeof __firebase_config !== 'undefined' ? __firebase_config : '{}');
        const initialAuthToken = typeof __initial_auth_token !== 'undefined' ? __initial_auth_token : null;

        if (Object.keys(firebaseConfig).length === 0) {
            console.error("Firebase config is missing.");
            return;
        }

        const app = initializeApp(firebaseConfig);
        const db = getFirestore(app);
        const auth = getAuth(app);

        setLogLevel('debug');
        
        if (initialAuthToken) {
            await signInWithCustomToken(auth, initialAuthToken);
        } else {
            await signInAnonymously(auth);
        }
        
        const userId = auth.currentUser?.uid || 'anonymous';
        console.log("Firebase initialized. User ID:", userId);

    } catch (error) {
        console.error("Firebase initialization failed:", error);
    }
};

initializeFirebase();

</script>

<script>
    $(document).ready(function() {
        $(window).on('scroll', function() {
            var scrolled = $(window).scrollTop();
            $('body').css('background-position', '0 ' + (-scrolled * 0.3) + 'px');
            $('body').css('background-position-y', scrolled * 0.1 + 'px');
        });

        $('.btn-read-more').on('click', function(e) {
            $(this).addClass('opacity-50');
            setTimeout(() => {
                $(this).removeClass('opacity-50');
            }, 300);
        });

        $('.profile-image-container').hover(
            function() {
                $(this).find('.name-box').css({
                    'transform': 'translate(-50%, 0%)', 
                    'box-shadow': '0 0 20px rgba(187, 134, 252, 0.5)' 
                });
            },
            function() {
                $(this).find('.name-box').css({
                    'transform': 'translate(-50%, 50%)', 
                    'box-shadow': '0 5px 15px rgba(0, 0, 0, 0.5)' 
                });
            }
        );
    });
</script>
