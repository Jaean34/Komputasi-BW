<?php 
$dataDiri = $dataDiri ?? ['nama' => 'Portofolio', 'profesi' => 'Designer']; 
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portofolio | <?= htmlspecialchars($dataDiri['nama']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100..900&display=swap" rel="stylesheet">
    <style>
        :root {
            --color-dark-blue: #080C2C; 
            --color-purple-dark: #3700b3;
            --color-purple-light: #6200ee;
            --color-pink: #BB86FC;
            --color-white: #ffffff;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--color-dark-blue);
            color: var(--color-white);
            min-height: 100vh;
            margin: 0;
            padding: 0;
            background-image: linear-gradient(135deg, #090e38 0%, #170068 100%);
            background-attachment: fixed; 
        }

        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1; 
            background-size: 50px 50px;
            background-image: linear-gradient(to right, rgba(255, 255, 255, 0.05) 1px, transparent 1px),
                              linear-gradient(to bottom, rgba(255, 255, 255, 0.05) 1px, transparent 1px);
        }

        .navbar {
            background-color: transparent !important;
            padding-top: 2rem;
        }

        .navbar-brand {
            font-weight: 700;
            font-size: 1.2rem;
            color: var(--color-white) !important;
        }

        .nav-link {
            color: rgba(255, 255, 255, 0.7) !important;
            margin-right: 1.5rem;
            font-size: 1rem;
            font-weight: 500;
            transition: color 0.3s;
        }
        .nav-link:hover, .nav-link.active {
            color: var(--color-white) !important;
        }
        
        .nav-link.btn-about {
            border: 2px solid var(--color-pink);
            border-radius: 20px;
            padding: 0.5rem 1.5rem;
            color: var(--color-pink) !important;
            background-color: transparent;
        }
        .nav-link.btn-about:hover {
            background-color: rgba(187, 134, 252, 0.1);
        }

        .hero-section {
            padding-top: 5rem;
            padding-bottom: 5rem;
        }

        .profile-title {
            font-size: 4rem;
            font-weight: 900;
            line-height: 1.1;
            margin-bottom: 0.5rem;
        }

        .profile-subtitle {
            font-size: 1.8rem;
            font-weight: 400;
            color: rgba(255, 255, 255, 0.7);
            margin-bottom: 2rem;
        }

        .profile-description {
            font-size: 1.1rem;
            line-height: 1.8;
            color: rgba(255, 255, 255, 0.8);
            max-width: 550px;
            margin-bottom: 3rem;
        }

        .btn-read-more {
            background: linear-gradient(90deg, #6200ee 0%, #BB86FC 100%);
            border: none;
            color: var(--color-white);
            font-weight: 600;
            padding: 0.8rem 2rem;
            border-radius: 8px;
            transition: opacity 0.3s;
        }
        .btn-read-more:hover {
            opacity: 0.9;
        }
        
        .btn-arrow {
            font-size: 2rem;
            color: rgba(255, 255, 255, 0.5);
            margin-left: 1rem;
            cursor: pointer;
        }

        .profile-image-container {
            position: relative;
            width: 350px; 
            height: 450px; 
            margin: 0 auto;
            transition: transform 0.5s ease-in-out, box-shadow 0.5s ease-in-out;
            cursor: pointer;
        }
        .profile-image-container:hover {
            transform: translateY(-10px); 
            box-shadow: 0 15px 40px rgba(187, 134, 252, 0.2); 
        }
        
        .profile-shape {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            border-radius: 60% 40% 70% 30% / 30% 60% 40% 70%; 
            background: linear-gradient(135deg, #FF6F61 0%, #BB86FC 100%); 
            opacity: 0.8;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            overflow: hidden; 
            transform: rotate(-10deg); 
            transition: transform 0.5s ease-in-out;
        }

        .profile-image-container:hover .profile-shape {
             transform: rotate(-5deg); 
        }
        
        .profile-img {
            position: absolute;
            width: 90%;
            height: 90%;
            object-fit: cover;
            top: 5%;
            left: 5%;
            border-radius: 60% 40% 70% 30% / 30% 60% 40% 70%; 
            transform: rotate(10deg); 
            z-index: 2;
        }

        @keyframes rotateText {
            from {
                transform: translate(-50%, -50%) rotate(0deg);
            }
            to {
                transform: translate(-50%, -50%) rotate(360deg);
            }
        }
        
        .circular-text {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 150%;
            height: 150%;
            z-index: 3;
            pointer-events: none;
            animation: rotateText 10s linear infinite; 
        }
        .circular-text-path {
            fill: none;
        }
        .circular-text text {
            fill: rgba(255, 255, 255, 0.5);
            font-size: 10px;
            letter-spacing: 3px;
            font-weight: 600;
            text-transform: uppercase;
        }
        
        .name-box {
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translate(-50%, 50%); 
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 10px;
            padding: 0.75rem 2rem;
            text-align: center;
            font-weight: 700;
            font-size: 1.1rem;
            color: var(--color-white);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.5);
            width: 80%;
            z-index: 10;
            transition: transform 0.5s ease-in-out, box-shadow 0.5s ease-in-out;
        }

        @media (max-width: 992px) {
            .profile-title {
                font-size: 3rem;
            }
            .profile-image-container {
                margin-top: 4rem;
                width: 300px;
                height: 400px;
            }
            .navbar-nav {
                margin-top: 1rem;
                text-align: center;
            }
        }
        @media (max-width: 576px) {
            .profile-title {
                font-size: 2.5rem;
            }
            .profile-subtitle {
                font-size: 1.4rem;
            }
            .btn-arrow {
                display: none;
            }
        }
        
        .project-card {
            background-color: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            padding: 1.5rem;
            margin-bottom: 2rem;
            transition: transform 0.3s, background-color 0.3s;
        }
        .project-card:hover {
            transform: translateY(-5px);
            background-color: rgba(187, 134, 252, 0.05);
        }
        .tag-badge {
            display: inline-block;
            background-color: var(--color-purple-light);
            color: var(--color-white);
            padding: 0.3rem 0.7rem;
            border-radius: 6px;
            font-size: 0.8rem;
            margin-right: 0.5rem;
            margin-top: 0.5rem;
        }
        
        .skill-item {
            display: flex;
            align-items: center;
            margin-bottom: 1rem;
        }
        .skill-bar-container {
            flex-grow: 1;
            height: 8px;
            background-color: rgba(255, 255, 255, 0.1);
            border-radius: 4px;
            overflow: hidden;
            margin-left: 1rem;
        }
        .skill-bar {
            height: 100%;
            border-radius: 4px;
            transition: width 1s ease-out;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container-fluid px-5">
        <a class="navbar-brand" href="phpbs.php?page=home">PORTFOLIO DESIGN</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto align-items-lg-center">
                <li class="nav-item">
                    <a class="nav-link <?= $page === 'home' ? 'active' : '' ?>" href="phpbs.php?page=home">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= $page === 'collection' ? 'active' : '' ?>" href="collection.php?page=collection">Collection</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link btn-about <?= $page === 'about' ? 'active' : '' ?>" href="about.php?page=about">About me</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= $page === 'favorite' ? 'active' : '' ?>" href="favorit.php?page=favorite">Favorite</a>
                </li>
                <li class="nav-item d-none d-lg-block"> 
                    <a class="nav-link <?= $page === 'contact' ? 'active' : '' ?>" href="contact.php?page=contact">Contact</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
</html>