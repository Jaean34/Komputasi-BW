<?php
$currentPage = 'contact';

include 'partials.php'; 
?>
<div class="container my-5">
    <div class="row justify-content-center">
        <div class="col-lg-6">
            <h2 class="text-center mb-4 profile-title" style="font-size: 3rem;">Contact Me</h2>
            <div class="card p-4 bg-dark" style="border-radius: 12px;">
                < class="text-center mb-2"><p style="color:white;">
                    Tertarik untuk berkolaborasi atau ingin sekadar menyapa? Silakan kirim pesan melalui formulir di bawah ini.
                </p>
                <form>
                    <div class="mb-3">
                        <p style="color:white;">
                        <label for="name" class="form-label text-pink">Nama Lengkap</label>
                        <input type="text" class="form-control" id="name" style="background: rgba(255, 255, 255, 0.1); border: none; color: white;" required>
                    </div>
                    <div class="mb-3">
                        <p style="color:white;">
                        <label for="email" class="form-label text-pink">Email</label>
                        <input type="email" class="form-control" id="email" style="background: rgba(255, 255, 255, 0.1); border: none; color: white;" required>
                    </div>
                    <div class="mb-3">
                        <p style="color:white;">
                        <label for="message" class="form-label text-pink">Pesan</label>
                        <textarea class="form-control" id="message" rows="4" style="background: rgba(255, 255, 255, 0.1); border: none; color: white;" required></textarea>
                    </div>
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-read-more">Send Message</button>
                    </div><br>
                </form>            
            </div>
        </div>
    </div>
</div>
<?php include 'partials.php'; ?>
