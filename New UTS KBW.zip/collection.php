<?php
// Data Simulasi (Siap Diganti dengan Database)
$projects = [
    ['title' => 'Educational Web', 'description' => 'Situs pembelajaran online yang mengajarkan kepada para pengguna/masyrakat tentang bahaya narkoba. dampak, serta cara mecegah dari penggunaan narkoba.', 'tags' => 'ActionScript'],
    ['title' => 'E-Commerce', 'description' => 'Membuat sebuah website untuk penjualan donat sehingga dapat membantu meningkatkan jual pasar.', 'tags' => 'ActionScript'],
    ['title' => 'Mobile & Desktop for Web & App Design', 'description' => 'Desain dan prototipe Figma untuk layanan makanan dan edukasi, berfokus pada praktik terbaik UX/UI.', 'tags' => 'Figma, UX/UI, Prototyping'],
];

$currentPage = 'collection';

include 'partials.php'; 

?>
<div class="container my-5">
    <h2 class="text-center mb-5 profile-title" style="font-size: 3rem;">My Collection</h2>
    <div class="row justify-content-center">
        <?php foreach ($projects as $project): ?>
        <div class="col-lg-4 col-md-6 mb-4">
            <div class="project-card h-100">
                <h4 class="text-white mb-3"><?= htmlspecialchars($project['title']) ?></h4>
                <p class="text-muted small"><p style="color:white;">Project/Application</p>
                <p><?= htmlspecialchars($project['description']) ?></p>
                <div class="mt-3">
                    <?php foreach (explode(', ', $project['tags']) as $tag): ?>
                        <span class="tag-badge"><?= htmlspecialchars(trim($tag)) ?></span>
                    <?php endforeach; ?>
                </div>
                <div class="d-flex justify-content-end mt-3">
                    <button class="btn btn-sm text-info me-2">Edit</button>
                    <button class="btn btn-sm text-danger">Delete</button>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <div class="text-center mt-5">
        <button class="btn btn-read-more">Add New Project</button>
    </div>
</div>
<?php include 'partials.php'; ?>
