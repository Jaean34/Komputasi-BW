<?php
$dataDiri = [
    'nama' => 'Karine Olivia Permana', 
    'profesi' => 'Web Developer', 
    'keterangan_profesi' => 'Web Developer',
    'deskripsi' => 'Halo, nama saya Karine. Saya adalah seorang pengembang web yang bersemangat dalam membangun solusi web berskala besar. Saya fokus pada efisiensi kode dan pengalaman pengguna yang luar biasa. Saya lahir di Jakarta dan kini berdomisili di Tangerang Selatan.'
];

$currentPage = 'about'; 

include 'partials.php'; 

?>
<div class="container my-5">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <h2 class="text-center mb-4 profile-title" style="font-size: 3rem;">About Me</h2>
            <div class="card p-5 bg-dark" style="border-radius: 12px;">
                <h4 class="text-white mb-3">Karine Olivia Permana</h4>
                <p class="fs-5 mb-4 text-white-50"><?= htmlspecialchars($dataDiri['profesi']) ?> | Web Dev Enthusiast</p>
                
                <p style="font-size: 1.1rem; line-height: 1.5; color:white;">
                    Saya adalah Karine, seorang web developer yang memiliki pengalaman singkat dalam pengerjaan web development, mulai dari desain UI/UX yang kemudian dikembangkan menjadi sebuah website dengan menggunakan ActionScript.
                </p>
                <p style="font-size: 1.1rem; line-height: 1.5; color:white;">
                    Saya lahir di Jakarta dan saat ini tinggal di Tangerang Selatan. Meskipun pengalamana saya singkat, namun banyak khal yang saya pelajari. Saya percaya bahwa kunci pengembangan yang baik terletak pada kolaborasi tim yang kuat dan hasrat untuk terus belajar.
                </p><p style="color:white;">
                <h5 class="text-white mt-4">Pendidikan</h5>
                <ul class="list-unstyled text-white">
                    <li class="mb-2"><strong>Universitas Pembangunan Jaya</strong> - S1 Informatika (2024 - Sekarang)</li>
                    <li><strong>SMK Bina Informatika</strong> - 2020-2024</li>
                </ul>
                <h5 class="text-pink mt-4"><p style="color:white;">Lokasi</h5>
                <p style="color:white;">Berasal dari: Jakarta <br> Berdomisili di: Tangerang Selatan</p>
            </div>
        </div>
    </div>
</div>
<?php include 'partials.php'; ?>
