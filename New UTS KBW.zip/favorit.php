<?php
$favorites = [
    ['name' => 'HTML', 'level' => 'Advanced', 'color' => '#61DAFB'],
    ['name' => 'CSS', 'level' => 'Advanced', 'color' => '#38B2AC'],
    ['name' => 'Python', 'level' => 'Intermediate', 'color' => '#339933'],
    ['name' => 'Figma', 'level' => 'Advanced', 'color' => '#A259FF'],
];

$currentPage = 'favorite';

include 'partials.php'; 

?>
<div class="container my-5">
    <h2 class="text-center mb-5 profile-title" style="font-size: 3rem;">My Favorite Stacks & Skills</h2>
    <div class="row justify-content-center">
        <?php foreach ($favorites as $fav): ?>
            <?php
                $percent = match ($fav['level']) {
                    'Advanced' => '90%',
                    'Intermediate' => '70%',
                    'Beginner' => '40%',
                    default => '50%',
                };
            ?>
            <div class="col-lg-6 mb-4">
                <div class="skill-item">
                    <div style="width: 120px; font-weight: 600; color: var(--color-pink);"><?= htmlspecialchars($fav['name']) ?></div>
                    <div class="skill-bar-container">
                        <div class="skill-bar" style="width: <?= $percent ?>; background-color: <?= htmlspecialchars($fav['color']) ?>;"></div>
                    </div>
                    <div style="width: 80px; text-align: right; font-size: 0.9rem; color: rgba(255, 255, 255, 0.7);"><?= $percent ?></div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>
<?php include 'partials.php'; ?>
